# -*- coding: utf-8 -*-
"""演示入口：用一条真实（非编造）的混合问法跑通 RAG Agent。

问法同时命中：
  - RAG 知识（SOP-1 缺陷率判定）做风险判定
  - MCP 工具（low_stock_skus）取真实库存/缺陷率数据
这正是「方法论 + 真实数据混合问答」的典型链路。
"""
from rag_agent import SupplyChainRagAgent, format_answer

DEMO_QUERY = "Mumbai 仓哪个 SKU 最该优先补货（结合库存覆盖与缺陷风险）？"


def main() -> None:
    agent = SupplyChainRagAgent()
    answer = agent.run(DEMO_QUERY)
    print(format_answer(answer))


if __name__ == "__main__":
    main()
