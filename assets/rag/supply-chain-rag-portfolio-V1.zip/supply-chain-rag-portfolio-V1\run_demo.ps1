$python = Get-Command python -ErrorAction SilentlyContinue
if ($python) {
    & $python.Source .\src\demo.py
} else {
    & "$env:USERPROFILE\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" .\src\demo.py
}
