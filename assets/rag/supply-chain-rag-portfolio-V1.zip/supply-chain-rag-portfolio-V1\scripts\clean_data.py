# -*- coding: utf-8 -*-
"""
数据清洗脚本 · supply-chain-rag-portfolio
来源：真实公开数据集 supply_chain_data.csv（GitHub: SARATH-PSBN/vemu-aicw，100 行快消/美妆供应链样本）
作用：把原始 CSV 规整成工具层（MCP）可直接消费的结构化数据。
清洗规则（用户拍板）：
  1) 四舍五入：price/revenue/各类 cost -> 2 位；defect_rate(比率) -> 4 位；时间(天) -> 1 位；计数 -> 0 位
  2) 去重改名：同义列合并（Lead times == Lead time），全量改为 snake_case 防止工具字段对不上
  3) 保留城市维度：Location 原样保留（Kolkata/Mumbai/Chennai/Bangalore/Delhi）
注意：本脚本只处理"数值/文本结构化数据"；文本知识（SOP/公式）由 knowledge_base/ 下的 md 提供，走 RAG。
"""
import csv, os

SRC = os.path.join(os.path.dirname(__file__), "..", "data", "real_supply_chain.csv")
OUT = os.path.join(os.path.dirname(__file__), "..", "data", "clean_supply_chain.csv")

# ---- 列名映射：原始 -> 规范化 snake_case ----
RENAME = {
    "Product type": "product_type",
    "SKU": "sku",
    "Price": "price",
    "Availability": "availability",
    "Number of products sold": "units_sold",
    "Revenue generated": "revenue",
    "Customer demographics": "customer_demographics",
    "Stock levels": "stock_level",
    "Lead times": "lead_times_days",         # 与 'Lead time' 含义不同（r≈-0.003，独立），分别保留
    "Order quantities": "order_qty",
    "Shipping times": "shipping_time_days",
    "Shipping carriers": "shipping_carrier",
    "Shipping costs": "shipping_cost",        # 运费
    "Supplier name": "supplier_name",
    "Location": "location",                   # 城市维度，保留
    "Lead time": "lead_time_days",            # 同义重复列
    "Production volumes": "production_volume",
    "Manufacturing lead time": "mfg_lead_time_days",
    "Manufacturing costs": "mfg_cost",        # 制造成本
    "Inspection results": "inspection_result",
    "Defect rates": "defect_rate",            # 比率
    "Transportation modes": "transport_mode",
    "Routes": "route",
    "Costs": "total_cost",                    # 总成本
}

# ---- 四舍五入规则：列 -> 保留小数位（仅对可解析为数字的值生效）----
ROUND = {
    "price": 2, "revenue": 2, "shipping_cost": 2, "mfg_cost": 2, "total_cost": 2,
    "defect_rate": 4,
    "lead_time_days": 1, "lead_times_days": 1, "shipping_time_days": 1, "mfg_lead_time_days": 1,
    "units_sold": 0, "stock_level": 0, "order_qty": 0, "production_volume": 0,
}


def to_num(v):
    try:
        return float(str(v).replace(",", "").strip())
    except Exception:
        return None


def main():
    rows = list(csv.DictReader(open(SRC, encoding="utf-8")))
    raw_cols = list(rows[0].keys())

    # 1) 同义列一致性校验：Lead times / Lead time 必须逐行相等，否则报错而非静默合并
    dup_groups = {}
    for c in raw_cols:
        dup_groups.setdefault(RENAME[c], []).append(c)
    for canon, srcs in dup_groups.items():
        if len(srcs) > 1:
            a, b = srcs[0], srcs[1]
            mism = sum(1 for r in rows if str(r[a]).strip() != str(r[b]).strip())
            print(f"[去重] {srcs} -> {canon}  不一致行数={mism}（应为0）")
            assert mism == 0, f"同义列 {srcs} 取值不一致，请人工核对后再合并！"

    # 2) 重命名 + 去重合并
    out_cols = []
    seen = set()
    for c in raw_cols:
        canon = RENAME[c]
        if canon in seen:
            continue  # 同义列只保留第一次出现的那一列
        seen.add(canon)
        out_cols.append(canon)

    out_rows = []
    for r in rows:
        nr = {}
        used = set()
        for c in raw_cols:
            canon = RENAME[c]
            if canon in used:
                continue
            used.add(canon)
            val = r[c]
            n = to_num(val)
            if n is not None and canon in ROUND:
                nr[canon] = round(n, ROUND[canon])
            else:
                nr[canon] = val.strip()
        out_rows.append(nr)

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=out_cols)
        w.writeheader()
        w.writerows(out_rows)
    print(f"[完成] 输出 {len(out_rows)} 行 x {len(out_cols)} 列 -> {os.path.abspath(OUT)}")
    print("[列名]", out_cols)


if __name__ == "__main__":
    main()
