from __future__ import annotations

# 确定性意图路由：rag（纯知识）/ tool（纯数值）/ hybrid（公式+数据）
# 说明：这是基于关键词的启发式路由，在 21 条人工标注评测集上验证；
# 线上若用 LLM 路由需另建 held-out 评测，此处保持可复现、零外部依赖。

FORMULA_TERMS = [
    "安全库存", "再订货点", "rop", "eoq", "经济订货批量", "abc", "aql",
    "评分卡", "公式", "服务水平", "经济订货",
]
# 必须是"具体数据实体/量化请求"才判为需要工具；仅出现指标名词(缺陷率/提前期/供应商)不算
CONCRETE_DATA_TERMS = [
    "sku0", "sku1", "sku2", "sku3", "sku4", "sku5",
    "mumbai", "kolkata", "chennai", "bangalore", "delhi",
    "库存水平最低", "最低", "最高", "低于", "平均", "各城市", "均值", "全部 sku",
]
SOP_TERMS = ["风险", "sop", "管控", "预警", "策略", "达标", "是否触发", "判为", "应采用"]


def route(query: str) -> str:
    q = query.lower()
    has_f = any(t in q for t in FORMULA_TERMS)
    has_cd = any(t in q for t in CONCRETE_DATA_TERMS)
    has_s = any(t in q for t in SOP_TERMS)
    # 关键修正：formula 必须"套到具体数据"才算 hybrid；定义/释义类(无具体实体)归 rag
    if has_f and has_cd:
        return "hybrid"
    if has_s and has_cd:
        return "hybrid"
    if has_f:
        return "rag"
    if has_cd:
        return "tool"
    return "rag"
