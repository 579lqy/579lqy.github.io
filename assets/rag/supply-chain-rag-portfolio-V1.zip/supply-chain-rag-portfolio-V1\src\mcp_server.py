# -*- coding: utf-8 -*-
"""供应链协同 MCP 风格 JSON-RPC 服务（本地原型，零外部依赖）。

支持的方法：
  - tools/list    : 返回 7 个真实数据工具的能力清单（tool_manifest）
  - tools/call    : 调用具体工具
        find_sku / low_stock_skus / supplier_defect_ranking /
        avg_lead_time_by_location / lead_time_stats /
        abc_classification / supplier_scorecard
      + generate_strategy（走 RAG Agent：意图路由 + 知识检索 + 工具数值）

所有数值/统计工具直接查真实数据（clean_supply_chain.csv），不经过文本检索——
这就是「RAG 管知识、MCP 管数据」的架构分工在原型里的落地。
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

# 允许直接 `python src/mcp_server.py` 运行
sys.path.insert(0, str(Path(__file__).resolve().parent))

from mcp_tools import (
    abc_classification,
    avg_lead_time_by_location,
    find_sku,
    lead_time_stats,
    low_stock_skus,
    supplier_defect_ranking,
    supplier_scorecard,
    tool_manifest,
)
from rag_agent import SupplyChainRagAgent


# 真实工具名 -> 调用闭包（参数从 JSON-RPC arguments 透传）
TOOL_FUNCS = {
    "find_sku": lambda a: find_sku(a["sku"]),
    "low_stock_skus": lambda a: low_stock_skus(
        location=a.get("location"),
        threshold=a.get("threshold"),
        top_n=a.get("top_n"),
    ),
    "supplier_defect_ranking": lambda a: supplier_defect_ranking(),
    "avg_lead_time_by_location": lambda a: avg_lead_time_by_location(),
    "lead_time_stats": lambda a: lead_time_stats(),
    "abc_classification": lambda a: abc_classification(),
    "supplier_scorecard": lambda a: supplier_scorecard(a["sku"]),
}


def handle_request(request: dict[str, Any]) -> dict[str, Any]:
    method = request.get("method")
    params = request.get("params", {})
    request_id = request.get("id")
    try:
        if method == "tools/list":
            result = tool_manifest()
        elif method == "tools/call":
            result = call_tool(params.get("name"), params.get("arguments", {}))
        else:
            raise ValueError(f"未知方法: {method}")
        return {"jsonrpc": "2.0", "id": request_id, "result": result}
    except Exception as exc:  # noqa: BLE001 - JSON-RPC 要求把错误包进响应
        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "error": {"code": -32000, "message": str(exc)},
        }


def call_tool(name: str, arguments: dict[str, Any]) -> dict[str, Any]:
    if name == "generate_strategy":
        return SupplyChainRagAgent().run(query=arguments["query"])
    if name in TOOL_FUNCS:
        return TOOL_FUNCS[name](arguments)
    raise ValueError(f"未知工具: {name}")


def main() -> None:
    parser = argparse.ArgumentParser(description="供应链协同 MCP 风格 JSON-RPC 服务")
    parser.add_argument("--request-file", help="读取 UTF-8 JSON-RPC 请求文件")
    args = parser.parse_args()

    if args.request_file:
        request = json.loads(Path(args.request_file).read_text(encoding="utf-8"))
        print(json.dumps(handle_request(request), ensure_ascii=False), flush=True)
        return

    for line in sys.stdin:
        if not line.strip():
            continue
        request = json.loads(line)
        print(json.dumps(handle_request(request), ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
