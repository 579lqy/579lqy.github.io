# -*- coding: utf-8 -*-
"""RAG Agent 冒烟测试（真实数据集口径，非编造）。

断言对象为「意图路由 + 场景识别 + 证据召回」这一可复现行为，
不依赖 LLM；与 tests/eval_rag.py 的 21 条评测集共享同一套真实实现。
"""
from __future__ import annotations

from rag_agent import SupplyChainRagAgent


def test_rag_intent() -> None:
    agent = SupplyChainRagAgent()
    answer = agent.run("如何计算安全库存？给出公式与各参数含义。")
    assert answer["intent"] == "rag"
    assert "RAG 检索" in answer["scenario"]
    assert answer["evidence"], "RAG 类必须有召回证据"


def test_tool_intent() -> None:
    agent = SupplyChainRagAgent()
    answer = agent.run("各城市的平均提前期(lead_time_days)各是多少？")
    assert answer["intent"] == "tool"
    assert "MCP 工具" in answer["scenario"]
    assert answer["findings"], "tool 类必须给出数据结论"


def test_hybrid_intent() -> None:
    agent = SupplyChainRagAgent()
    answer = agent.run("Mumbai 仓哪个 SKU 最该优先补货（结合库存覆盖与缺陷风险）？")
    assert answer["intent"] == "hybrid"
    assert "混合问答" in answer["scenario"]
    assert answer["evidence"], "hybrid 类必须同时有知识证据"
