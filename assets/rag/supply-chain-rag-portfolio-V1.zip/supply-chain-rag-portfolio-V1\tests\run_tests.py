# -*- coding: utf-8 -*-
"""统一测试入口：冒烟测试 + 评测流水线真实性校验。

运行：
    python tests/run_tests.py

会执行：
  1) test_rag_agent 的 3 条冒烟用例（意图/场景/证据）
  2) eval_rag 的 21 条真实评测，并断言三类指标达到交付口径
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "tests"))

from test_rag_agent import (  # noqa: E402
    test_hybrid_intent,
    test_rag_intent,
    test_tool_intent,
)
import eval_rag  # noqa: E402


def _run_smoke() -> None:
    for fn in (test_rag_intent, test_tool_intent, test_hybrid_intent):
        fn()
        print(f"PASS {fn.__name__}")


def _run_eval() -> None:
    summary = eval_rag.main()
    assert summary["end2end_accuracy"] == 100.0, f"e2e 应为100%: {summary}"
    assert summary["recall_at_3"] == 100.0, f"Recall@3 应为100%: {summary}"
    assert summary["intent_accuracy"] >= 90.0, f"intent 应>=90%: {summary}"
    print(
        f"PASS eval_rag  intent={summary['intent_accuracy']}%  "
        f"Recall@3={summary['recall_at_3']}%  e2e={summary['end2end_accuracy']}%"
    )


def main() -> None:
    _run_smoke()
    _run_eval()
    print("\nALL TESTS PASSED.")


if __name__ == "__main__":
    main()
