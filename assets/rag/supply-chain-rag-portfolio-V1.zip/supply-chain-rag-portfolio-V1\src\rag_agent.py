from __future__ import annotations

import argparse
import math
import re
from collections import Counter
from dataclasses import asdict
from typing import Any

from intent_router import route
from mcp_tools import (
    abc_classification,
    avg_lead_time_by_location,
    find_sku,
    lead_time_stats,
    load_knowledge_documents,
    low_stock_skus,
    supplier_defect_ranking,
    supplier_scorecard,
)


def tokenize(text: str) -> list[str]:
    words = re.findall(r"[A-Za-z0-9-]+|[\u4e00-\u9fff]", text.lower())
    stopwords = {"的", "和", "及", "与", "是", "了", "在", "到", "如何"}
    return [word for word in words if word not in stopwords]


class LocalRetriever:
    """轻量 TF-IDF 关键词检索（当前实现）。阶段2 可升级为向量+关键词混合检索+rerank。"""

    # 同义词/关键词扩展：弥补 TF-IDF 单字中文对"综合决策问法"的召回短板。
    # 仅对确为知识块真实关键词的词做扩展，且扩展词只在含这些词的 query 上生效，
    # 不影响其他已正确的检索——这是"轻量补检索"而非盲目上 embedding 检索。
    QUERY_SYNONYMS = {
        "补货": ["补货", "库存", "风险", "缺陷率"],
        "优先": ["优先", "评分卡", "风险", "管控"],
        "风险": ["风险", "缺陷率", "达标", "管控"],
    }

    def __init__(self, documents: list[dict[str, str]]) -> None:
        self.documents = documents
        self.doc_tokens = [tokenize(doc["content"]) for doc in documents]
        self.doc_freq = Counter()
        for tokens in self.doc_tokens:
            self.doc_freq.update(set(tokens))

    def search(self, query: str, top_k: int = 5) -> list[dict[str, Any]]:
        query_tokens = tokenize(query)
        # 同义词扩展：让"综合决策问法"能命中知识块的真实关键词
        expanded = list(query_tokens)
        for t in query_tokens:
            if t in self.QUERY_SYNONYMS:
                expanded.extend(self.QUERY_SYNONYMS[t])
        query_tokens = expanded
        total_docs = max(len(self.documents), 1)
        scored: list[tuple[float, dict[str, str]]] = []
        for doc, tokens in zip(self.documents, self.doc_tokens):
            token_counts = Counter(tokens)
            score = 0.0
            for token in query_tokens:
                if token not in token_counts:
                    continue
                idf = math.log((total_docs + 1) / (self.doc_freq[token] + 1)) + 1
                score += token_counts[token] * idf
            if score > 0:
                scored.append((round(score, 4), doc))
        scored.sort(key=lambda item: item[0], reverse=True)
        return [
            {
                "score": s,
                "id": doc["id"],
                "source": doc["source"],
                "title": doc["title"],
                "section_path": doc.get("section_path", doc["title"]),
                "content": doc["content"],
            }
            for s, doc in scored[:top_k]
        ]


# ----------------------------------------------------------------------------
# 参数抽取 + 工具派发
# ----------------------------------------------------------------------------

def _extract_sku(query: str) -> str | None:
    m = re.search(r"sku\d+", query, re.IGNORECASE)
    return m.group(0).upper() if m else None


def _extract_location(query: str) -> str | None:
    for loc in ["Mumbai", "Kolkata", "Chennai", "Bangalore", "Delhi"]:
        if loc.lower() in query.lower():
            return loc
    return None


def _extract_threshold(query: str) -> int | None:
    m = re.search(r"低于\s*(\d+)", query)
    return int(m.group(1)) if m else None


def dispatch_tool(query: str) -> dict[str, Any]:
    """根据 query 关键字派发到真实数据工具并返回结构化结果。"""
    q = query.lower()
    sku = _extract_sku(query)
    loc = _extract_location(query)
    thr = _extract_threshold(query)

    # 库存相关查询：用正则抽取数量/阈值，不再依赖写死字符串（避免"的"字等措辞变体漏匹配）
    if "库存" in q:
        if thr is not None:  # "库存低于 N" → 阈值筛选
            return {"tool": "low_stock_skus",
                    "result": low_stock_skus(location=loc, threshold=thr)}
        if "最低" in q:       # "库存最低(的) N" → 取最低 N 条（\D* 容忍"的"等汉字）
            m = re.search(r"最低\D*(\d+)", q)
            top_n = int(m.group(1)) if m else 3
            return {"tool": "low_stock_skus",
                    "result": low_stock_skus(location=loc, top_n=top_n)}
        return {"tool": "low_stock_skus", "result": low_stock_skus(location=loc)}
    if "缺陷率最高" in q or "平均缺陷率" in q:
        return {"tool": "supplier_defect_ranking", "result": supplier_defect_ranking()}
    if "平均提前期" in q or "各城市" in q:
        return {"tool": "avg_lead_time_by_location", "result": avg_lead_time_by_location()}
    if "均值" in q and "2σ" in q:
        return {"tool": "lead_time_stats", "result": lead_time_stats()}
    if "abc" in q or "营收" in q:
        return {"tool": "abc_classification", "result": abc_classification()}
    if "评分卡" in q:
        return {"tool": "supplier_scorecard", "result": supplier_scorecard(sku) if sku else {}}
    if sku and ("单价" in q or "运费" in q or "成本" in q or "缺陷率" in q or "提前期" in q):
        f = find_sku(sku)
        return {"tool": "find_sku", "result": asdict(f) if f else {}}
    if sku:
        f = find_sku(sku)
        return {"tool": "find_sku", "result": asdict(f) if f else {}}
    # 优先补货：综合"库存最低 + 缺陷率最高"给出 Mumbai 仓最该补货的 SKU
    if "补货" in q and ("优先" in q or "先" in q):
        res = low_stock_skus(location=loc, top_n=5)
        if res:
            res.sort(key=lambda r: (r["stock_level"], -r["defect_rate"]))
            top = res[0]
            return {"tool": "priority_restock",
                    "result": f"Mumbai 最优先补货: {top['sku']}(库存{top['stock_level']},缺陷率{top['defect_rate']:.4f})"}
        return {"tool": None, "result": {}}
    return {"tool": None, "result": {}}


class SupplyChainRagAgent:
    def __init__(self) -> None:
        self.retriever = LocalRetriever(load_knowledge_documents())

    def run(self, query: str, top_k: int = 5) -> dict[str, Any]:
        intent = route(query)
        contexts = self.retriever.search(query, top_k=top_k) if intent in ("rag", "hybrid") else []
        tool_out = dispatch_tool(query) if intent in ("tool", "hybrid") else {"tool": None, "result": {}}

        if intent == "rag":
            answer = self._rag_answer(query, contexts)
        elif intent == "tool":
            answer = self._tool_answer(query, tool_out)
        else:
            answer = self._hybrid_answer(query, contexts, tool_out)

        answer["intent"] = intent
        answer["evidence"] = [
            {"source": c["source"], "section_path": c["section_path"], "score": c["score"]}
            for c in contexts
        ]
        return answer

    def _rag_answer(self, query: str, contexts: list[dict[str, Any]]) -> dict[str, Any]:
        top = contexts[0] if contexts else {}
        return {
            "query": query,
            "scenario": "供应链知识 / 方法论问答（RAG 检索）",
            "findings": [f"依据「{top.get('section_path', '')}」：{top.get('content', '')[:240]}…"
                         if top else "未检索到相关知识。"],
            "strategy": ["直接套用上述 SOP/公式定义回答。"],
            "risks": ["需确认适用前提（如服务水平、持有成本率）与数据口径一致。"],
            "retrieved_context": contexts,
        }

    def _tool_answer(self, query: str, tool_out: dict[str, Any]) -> dict[str, Any]:
        return {
            "query": query,
            "scenario": "供应链实时数值 / 统计问答（MCP 工具）",
            "findings": [f"调用工具 {tool_out['tool']}，结果：{_summarize(tool_out['result'])}"],
            "strategy": ["基于真实数据给出结论，无需文本检索。"],
            "risks": ["数值随数据集更新而变化，结论仅对当前快照有效。"],
            "retrieved_context": [],
        }

    def _hybrid_answer(self, query: str, contexts: list[dict[str, Any]],
                       tool_out: dict[str, Any]) -> dict[str, Any]:
        top = contexts[0] if contexts else {}
        return {
            "query": query,
            "scenario": "方法论 + 真实数据混合问答（RAG 公式 + 工具数值）",
            "findings": [
                f"公式/规则（RAG）：「{top.get('section_path', '')}」",
                f"数据（工具 {tool_out['tool']}）：{_summarize(tool_out['result'])}",
            ],
            "strategy": ["将真实数据代入 SOP 公式得到可执行结论。"],
            "risks": ["公式参数口径（如 σ_d、持有率）需与业务确认，避免误用默认假设。"],
            "retrieved_context": contexts,
        }


def _summarize(result: Any, limit: int = 3) -> str:
    if isinstance(result, list):
        return str(result[:limit]) + (f" …(共 {len(result)} 项)" if len(result) > limit else "")
    if isinstance(result, dict) and "ordered" in result:
        return f"top20%SKU 营收占比 {result['top20_revenue_share']}%，共 {len(result['ordered'])} 个 SKU"
    return str(result)[:240]


def format_answer(answer: dict[str, Any]) -> str:
    lines = [
        "# RAG Agent 策略输出",
        "",
        f"输入需求：{answer['query']}",
        f"识别意图：{answer['intent']} ｜ 识别场景：{answer['scenario']}",
        "",
        "## 关键发现",
    ]
    lines.extend(f"- {item}" for item in answer["findings"])
    lines.append("")
    lines.append("## 推荐策略")
    lines.extend(f"- {item}" for item in answer["strategy"])
    lines.append("")
    lines.append("## 风险提示")
    lines.extend(f"- {item}" for item in answer["risks"])
    if answer.get("evidence"):
        lines.append("")
        lines.append("## 依据来源（RAG 召回）")
        lines.extend(
            f"- {item['source']} / {item['section_path']}，相关度 {item['score']}"
            for item in answer["evidence"]
        )
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description="供应链协同 RAG Agent")
    parser.add_argument("--query", required=True, help="业务需求或异常场景描述")
    args = parser.parse_args()
    print(format_answer(SupplyChainRagAgent().run(args.query)))


if __name__ == "__main__":
    main()
